console.log("Entramos");
var items= document.getElementsByClassName("items");

var cantidad = items.lenght; //- 3


console.log(cantidad);
var div=document.createElement("div");
div;
div.innertxt= "Aprendiendo JavaScript"
var div = document.getElementsById("uno");
divUno.appendchild(div)

var lista=document.getElementsById("Lista");
var hijo = document.createElement("li");
hijo.innerText= "item 4(li nuevo)";
lista.appendchild(hijo);

document.getElementById('tres').style.color= 'red'
document.getElementById('lista').style.color= 'green';
